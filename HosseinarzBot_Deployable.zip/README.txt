
📦 راهنمای نصب ربات تریدر بر بستر Railway

1. برو به سایت https://railway.app
2. با GitHub وارد شو
3. New Project > Blank Project بزن
4. Upload Zip انتخاب کن و این فایل رو آپلود کن
5. در قسمت Environment متغیر TOKEN را برابر با توکن ربات تلگرامت قرار بده
6. روی Deploy بزن

🎯 حالا ربات تو فعاله و به تلگرام وصل شده!
