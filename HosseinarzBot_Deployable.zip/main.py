
def run_bot():
    print("✅ ربات شما با موفقیت اجرا شد.")

if __name__ == "__main__":
    run_bot()
